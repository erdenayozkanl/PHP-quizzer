<?php 
    require 'database.php';
    $id = 0;
     
    if ( !empty($_GET['id'])) {
        $id = $_GET['id'];
    }
     
    // keep track post values
    $id = $_GET['id'];
    echo 'TEST';
    // delete data
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "DELETE FROM customer WHERE id = ?";
    $q = $pdo->prepare($sql);
    $q->execute(array($id));
    Database::disconnect();
    header("Location: customer.php");
?>