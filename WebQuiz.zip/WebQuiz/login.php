<?php 
    $message = "";
    if($_SERVER["REQUEST_METHOD"] == 'POST'){
        $database = mysqli_connect("localhost", "root", "" , "webpro2");
        if (!$database) {
            echo mysqli_connect_errno() . ":" . mysqli_connect_error();
            die();
        }

        $username = mysqli_real_escape_string($database, $_POST['username']);
        $password = mysqli_real_escape_string($database, $_POST['password']);
        $query = "select * from login where username='$username' and password='$password'";
        if ($result=mysqli_query($database,$query))
        {
            $rowcount = mysqli_num_rows($result);
            if($rowcount == 1){
                $row = mysqli_fetch_assoc($result);
                //$message = 'Your information is correct! Welcome '.$row["name"];
                session_start();
                $_SESSION['user_session'] = "girildi";
                header("Location: customer.php");
            }else{
                $message = 'Your information is <b>NOT</b> correct!';
            }
        }

        mysqli_close($database);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP Login Form</title>
</head>
<body>
    <form method="POST" action="login.php" >
        <label for="username">Username</label>
        <input type="text" id="username" name="username">
        <label for="password">Password</label>
        <input type="password" name="password">
        <input type="submit" value"LOGIN">
    </form>
    <p><?php echo $message ?></p>
</body>
</html>