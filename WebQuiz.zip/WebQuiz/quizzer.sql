-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 08 May 2018, 12:03:48
-- Sunucu sürümü: 5.7.14
-- PHP Sürümü: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `quizzer`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `choices`
--

CREATE TABLE `choices` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `choices`
--

INSERT INTO `choices` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'Personal Hypertext Processor'),
(2, 1, 0, 'Private HOme PAge'),
(3, 1, 0, ' PHP: Personal HOme PAge'),
(4, 1, 0, 'PHP: asdasd Process'),
(5, 2, 0, '"Hello World";'),
(6, 2, 1, 'echo "Hello World";'),
(7, 2, 0, 'Document.Write("Hello World");'),
(22, 4, 0, 'Q7'),
(23, 4, 0, 'Tesla7'),
(19, 3, 0, 'asp'),
(20, 3, 1, 'php'),
(21, 4, 1, 'CR7');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `choices1`
--

CREATE TABLE `choices1` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(4) NOT NULL DEFAULT '0',
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `choices1`
--

INSERT INTO `choices1` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'http://www.turuncucerceve.com/upload/2013/07/animals1.jpg'),
(2, 1, 0, 'http://www.nkfu.com/wp-content/uploads/2017/04/Enerji-Ä°le-Ä°lgili-GÃ¶rseller-1.jpg'),
(3, 1, 0, 'http://www.nkfu.com/wp-content/uploads/2017/04/Enerji-%C4%B0le-%C4%B0lgili-G%C3%B6rseller-2.jpg'),
(4, 2, 0, 'http://i.milliyet.com.tr/Skorer600x298/2014/08/20/fft226_mf4691210.Jpeg'),
(5, 2, 1, 'https://images.performgroup.com/di/library/GOAL/47/46/cristiano-ronaldo-real-madrid_1owg123m78bl16jripie1ghkl.jpg?t=-1780920495&quality=90&w=1280'),
(6, 2, 0, 'http://i2.haber7.net//haber/haber7/photos/2018/09/portekiz_quaresmayi_konusuyor_1519629169_9634.jpg'),
(7, 2, 0, 'http://i.dailymail.co.uk/i/newpix/2018/02/23/07/4975EFDF00000578-5425549-image-a-29_1519369319581.jpg'),
(8, 3, 0, 'https://www.theflagshop.co.uk/media/catalog/product/cache/1/thumbnail/9df78eab33525d08d6e5fb8d27136e95/u/n/union-jack-flag-std.jpg'),
(9, 3, 0, 'https://cdn.britannica.com/97/897-004-6990FA31.jpg'),
(10, 3, 0, 'https://i.ytimg.com/vi/6ZPMtTIWnoc/hqdefault.jpg'),
(11, 3, 1, 'http://flags.fmcdn.net/data/flags/w580/cn.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `choices2`
--

CREATE TABLE `choices2` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(4) NOT NULL DEFAULT '1',
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `choices2`
--

INSERT INTO `choices2` (`id`, `question_number`, `is_correct`, `text`) VALUES
(1, 1, 1, 'https://images.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg?auto=compress&cs=tinysrgb&h=350'),
(2, 1, 0, 'https://www.fotografindir.net/wp-content/uploads/2018/04/yatan-aslan-resmi.jpg'),
(3, 1, 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSOIxi-9W992HIWiLd88lvB6Xv0ZFnFkIqA6LExm3_r7JnQ7xa'),
(4, 2, 1, 'https://www.featurepics.com/FI/Thumb300/20080917/Asian-Chinese-Business-Man-899183.jpg'),
(5, 2, 0, 'https://en.dailypakistan.com.pk/wp-content/uploads/2017/10/zayn-malik-leaves-one-direction-bbc-music-awards-red-carpet-arrivals.jpg'),
(6, 2, 0, 'https://i.ytimg.com/vi/c3iHabwa99w/hqdefault.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('erdenay', 'erdenay');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `questions`
--

CREATE TABLE `questions` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `questions`
--

INSERT INTO `questions` (`question_number`, `text`) VALUES
(1, 'What does PHP stand for?'),
(2, 'How do you write "Hello World" in PHP?'),
(3, 'What is the best server side language'),
(4, 'what is the shortcut of Cristiano Ronaldo?');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `questions1`
--

CREATE TABLE `questions1` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `questions1`
--

INSERT INTO `questions1` (`question_number`, `text`) VALUES
(1, 'Which one is an Animal?'),
(2, 'Which one is Cristiano Ronaldo?'),
(3, 'Which flag is not an Europe Country?');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `questions2`
--

CREATE TABLE `questions2` (
  `question_number` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `questions2`
--

INSERT INTO `questions2` (`question_number`, `text`) VALUES
(1, 'Which one is a real cat? Rate it.'),
(2, 'Which person is look like an Asian? Rate it.');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `choices`
--
ALTER TABLE `choices`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `choices1`
--
ALTER TABLE `choices1`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `choices2`
--
ALTER TABLE `choices2`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_number`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `choices`
--
ALTER TABLE `choices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- Tablo için AUTO_INCREMENT değeri `choices1`
--
ALTER TABLE `choices1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Tablo için AUTO_INCREMENT değeri `choices2`
--
ALTER TABLE `choices2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
