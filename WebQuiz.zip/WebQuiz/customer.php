<?php 
    session_start();
    if(!isset($_SESSION['user_session']))
    {
        header("Location: login.php");
    }
    $message = "";
    if($_SERVER["REQUEST_METHOD"] == 'POST'){
        $database = mysqli_connect("localhost", "root", "" , "webpro2");
        if (!$database) {
            echo mysqli_connect_errno() . ":" . mysqli_connect_error();
            die();
        }

        $name = $_POST["name"];
        $surname = $_POST["surname"];
        $phone = $_POST["phone"];

        $query = "insert into customer(name,surname,phone,username,password) values('".$name."','".$surname."','".$phone."','".generateRandomString()."','".generateRandomString()."')";
        if ($result=mysqli_query($database,$query))
        {
            echo 'Added Successfully!';
            /*$rowcount = mysqli_num_rows($result);
            if($rowcount == 1){
                $row = mysqli_fetch_assoc($result);
                $message = 'Your information is correct! Welcome '.$row["name"];
            }else{
                $message = 'Your information is <b>NOT</b> correct!';
            }*/
        }

        mysqli_close($database);
    }

    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP Login Form</title>
</head>
<body>
    <form method="POST" action="customer.php" >
        <label for="stdid">Customer Name</label>
        <input type="text" name="name">
        <label for="password">Customer Surname</label>
        <input type="text" name="surname">
        <label for="password">Customer Phone</label>
        <input type="text" name="phone">
        <input type="submit" value"SAVE">
    </form>
    <br>
    <a href="logout.php">LOGOUT</a>
    <p><?php echo $message ?></p>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "webpro2";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "SELECT * FROM customer";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["surname"]. " " . $row["phone"] . " "  . $row["username"];
            echo "<form action='remove.php' methot='GET'><input type='hidden' name='id' value='".$row["id"]."'></input><input type='submit' value='DELETE'></input></form>";
            echo "<br>";
        }
    } else {
        echo "0 results";
    }
$conn->close();
?>
</body>
</html>