<?php include 'database.php'; ?>
<!DOCTYPE html>
<html>
	<head>
	<style>
	body{
	font-family:arial;
	font-size:15px;
	line-height:1.5em;
}

li{
	list-style:none;
}

a{
	text-decoration:none;	
}

.container{
	width:60%;
	margin:0 auto;
	overflow:auto;
}

header{
	border-bottom:3px #f4f4f4 solid;
}

footer{
	border-top:3px #f4f4f4 solid;
	text-align:center;
	padding-top:5px;  
}


main{
	padding-bottom:20px;
}

a.start{
	display:inline-block;
	color:#666;
	background:#f4f4f4;
	border:1px dotted #ccc;
	padding:6px 13px;
}

.current{
	padding:10px;
	background:#f4f4f4;
	border:1px dotted #ccc;
	margin:20px 0 10px 0;
}
 
label{
	display:inline-block;
	width:180px;
}
input[type='text']{
	width:97%;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}
input{
	border: 2px solid black;
    padding: 10px;
    border-radius: 50px 20px;
	
}

input[type='number ']{
	width:50px;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}

@media only screen and(max-width:960px){
	.container{
		width:80%;		
	}
}
	</style>
<meta charset="UTF-8">
	<title>Questioner</title>
	<link rel="sytlesheet" href="sytle.css" type="text/css" />
	</head>
	<a href="index.php" class="start">Log Out</a>
<body>
	<header>
	<div class="container">
	<h1>Questioner</h1>
	</div>
	</header>
	<main>
	<div class="container">
		<h2>Adding Page</h2>
		<ul>
	
								<a href="add.php" class="start">Start Adding Multiple Choice</a>
				<a href="add1.php" class="start">Start Adding Image Choice</a>
								<a href="add2.php" class="start">Start Adding Rating Choice</a>
			
		</ul>

	</div>
	</main>
	<footer>
	<div class="container">
	<a href="index.php" class="start">Go back</a><br>
			Erdenay Özkanlı
	</div>
	</footer>
</body>
</html>