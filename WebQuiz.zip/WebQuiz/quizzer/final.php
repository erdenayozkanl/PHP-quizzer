<?php session_start(); ?>
<!DOCTYPE html>
<html>
	<head>
	<style>
	body{
	font-family:arial;
	font-size:15px;
	line-height:1.5em;
}

li{
	list-style:none;
}

a{
	text-decoration:none;	
}

.container{
	width:60%;
	margin:0 auto;
	overflow:auto;
}

header{
	border-bottom:3px #f4f4f4 solid;
}

footer{
	border-top:3px #f4f4f4 solid;
	text-align:center;
	padding-top:5px;  
}


main{
	padding-bottom:20px;
}

a.start{
	display:inline-block;
	color:#666;
	background:#f4f4f4;
	border:1px dotted #ccc;
	padding:6px 13px;
}

.current{
	padding:10px;
	background:#f4f4f4;
	border:1px dotted #ccc;
	margin:20px 0 10px 0;
}
 
label{
	display:inline-block;
	width:180px;
}
input[type='text']{
	width:97%;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}


input[type='number ']{
	width:50px;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}
input{
	border: 2px solid black;
    padding: 10px;
    border-radius: 50px 20px;
	
}
@media only screen and(max-width:960px){
	.container{
		width:80%;		
	}
}
	</style>
	<meta charset="utf-8" />
	<title>Questioner</title>
	<link rel="sytlesheet" href="sytle.css" type="text/css" />
	</head>
<body>
	<header>
	<div class="container">
	<h1>Questioner</h1>
	</div>
	</header>
	<main>
	<div class="container">
	<h2>You're Done! </h2>

			<p>Congrats! You have completed the test</p>
			<p>Final Score: <?php echo $_SESSION['score']?></p>
			<a href="index.php" class="start">Take Again</a>
	</div>
	</main>
	<footer>
	<div class="container">
			Erdenay Özkanlı
	</div>
	</footer>
</body>
</html>  