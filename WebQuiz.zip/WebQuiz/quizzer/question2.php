<?php include 'database.php'; ?>
<?php session_start();?>

<?php
$number=(int) $_GET['n'];

$query = "Select * from questions2";
$results=$mysqli->query($query) or die($mysqli->error.__LINE__);
	$total=$results->num_rows;




//for questions
$query="Select * from questions2 where question_number=$number";
$result=$mysqli->query($query) or die($mysqli->error.__LINE__);
$question=$result->fetch_assoc();

//for choices
$query="Select * from choices2 where question_number=$number";
//get results
$choices=$mysqli->query($query) or die($mysqli->error.__LINE__);

 ?>
<!DOCTYPE html>
<html>
	<head>
	<style>
	body{
	font-family:arial;
	font-size:15px;
	line-height:1.5em;
}
input{
	border: 2px solid black;
    padding: 10px;
    border-radius: 50px 20px;
	
}

li{
	list-style:none;
}

a{
	text-decoration:none;	
}

.container{
	width:60%;
	margin:0 auto;
	overflow:auto;
}

header{
	border-bottom:3px #f4f4f4 solid;
}

footer{
	border-top:3px #f4f4f4 solid;
	text-align:center;
	padding-top:5px;  
}


main{
	padding-bottom:20px;
}

a.start{
	display:inline-block;
	color:#666;
	background:#f4f4f4;
	border:1px dotted #ccc;
	padding:6px 13px;
}

.current{
	padding:10px;
	background:#f4f4f4;
	border:1px dotted #ccc;
	margin:20px 0 10px 0;
}
 
label{
	display:inline-block;
	width:180px;
}
input[type='text']{
	width:97%;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}


input[type='number ']{
	width:50px;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}

@media only screen and(max-width:960px){
	.container{
		width:80%;		
	}
}
	</style>
	<meta charset="utf-8" />
	<title>Questioner</title>
	<link rel="sytlesheet" href="sytle.css" type="text/css" />
	</head>
<body>
	<header>
	<div class="container">
	<h1>Questioner</h1>
	</div>
	</header>
	<main>
	<div class="container">
		<div class="current">Question <?php echo $question['question_number'];?> of <?php echo $total;?> </div>
		<p class="question">
			<?php echo $question['text'] ?>
		</p>
		
		<form method="post" action="process2.php">
			<ul class="choices">
			<?php while($row=$choices->fetch_assoc()): ?>
					<li><input name="choice" type="radio" value"<?php echo $row['id'];?>"/>
					<img src="<?php echo $row['text']; ?>" width="200"/>
					<?php echo "<br>";?>
					<input class="current" name="rate" type="number"/>
					</li>
			<?php endwhile; ?>
			</ul>
			
			<input type="submit" value="Submit" />
			
			<input type="hidden" name="number" value="<?php echo $number; ?>"/>
	</div>
	</main>
	<footer>
	<div class="container">
			Erdenay Özkanlı
	</div>
	</footer>
</body>
</html>  