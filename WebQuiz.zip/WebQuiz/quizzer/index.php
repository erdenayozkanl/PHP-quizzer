<?php include 'database.php'; ?>
<?php 
$query= "select * from questions";

$results=$mysqli->query($query) or die($mysqli->error.__LINE__);
$total = $results->num_rows;


$query1= "select * from questions1";

$results1=$mysqli->query($query1) or die($mysqli->error.__LINE__);
$total1 = $results1->num_rows;

$query2= "select * from questions2";

$results2=$mysqli->query($query2) or die($mysqli->error.__LINE__);
$total2 = $results2->num_rows;

?>
<!DOCTYPE html>
<html>
	<head>
				<a href="login1.php" class="start">Login Page</a>

	<style>
	body{
	font-family:arial;
	font-size:15px;
	line-height:1.5em;
}

li{
	list-style:none;
}

a{
	text-decoration:none;	
}

.container{
	width:60%;
	margin:0 auto;
	overflow:auto;
}

header{
	border-bottom:3px #f4f4f4 solid;
}

footer{
	border-top:3px #f4f4f4 solid;
	text-align:center;
	padding-top:5px;  
}


main{
	padding-bottom:20px;
}

a.start{
	display:inline-block;
	color:#666;
	background:#f4f4f4;
	border:1px dotted #ccc;
	padding:6px 13px;
}

.current{
	padding:10px;
	background:#f4f4f4;
	border:1px dotted #ccc;
	margin:20px 0 10px 0;
}
 
label{
	display:inline-block;
	width:180px;
}
input[type='text']{
	width:97%;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}
input{
	border: 2px solid black;
    padding: 10px;
    border-radius: 50px 20px;
	
}

input[type='number ']{
	width:50px;
	padding:4px;
	border-radius:5px;
	border:1px #ccc solid;
}

@media only screen and(max-width:960px){
	.container{
		width:80%;		
	}
}
	</style>
<meta charset="UTF-8">
	<title>PHP Quizzer</title>
	<link rel="sytlesheet" href="sytle.css" type="text/css" />
	</head>
<body>
	<header>
	<div class="container">
	<h1>PHP Quizzer</h1>
	</div>
	</header>
	<main>
	<div class="container">
		<h2>Test Your Knowledge</h2>
		
		<ul>
		<h3>This is a multiple choice test</h3>
			<li>
			<strong> Number of Questions:</strong><?php echo $total; ?>
			<li>
			<strong>Estimated Time:</strong> <?php echo $total *0.5; ?> Minutes!
			</li>
			<li>
			<a href="question.php?n=1" class="start">Start Multiple Choice Quiz</a>
			</li>
			
		</ul>
		
		<ul>
		<h3>This is a Image choice test</h3>
			<li>
			<strong> Number of Questions:</strong><?php echo $total1; ?>
			<li>
			<strong>Estimated Time:</strong> <?php echo $total1 *0.5; ?> Minutes!
			</li>
			<li>
			<a href="question1.php?n=1" class="start">Start İmage Choice Quiz</a>
			</li>
			
		</ul>
		
			<ul>
		<h3>This is a Rating choice test</h3>
			<li>
			<strong> Number of Questions:</strong><?php echo $total2; ?>
			<li>
			<strong>Estimated Time:</strong> <?php echo $total2 *0.5; ?> Minutes!
			</li>
			<li>
								<a href="question2.php?n=1" class="start">Start Rating Choice Quiz</a><br>
			</li>
			
		</ul>
		
		

				


	</div>
	</main>
	<footer>
	<div class="container">
			Erdenay Özkanlı
	</div>
	</footer>
</body>
</html>